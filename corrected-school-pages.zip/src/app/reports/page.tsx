"use client";

import { useMemo, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";
import { Download, Filter, BarChart3, PieChart as PieIcon, TrendingUp } from "lucide-react";
import { users, students, examResults, payments, attendance, classes } from "@/lib/mockData";
import { formatCurrency } from "@/lib/utils";

// Loose record type keeps this page compatible with flexible mock data.
type AnyRecord = Record<string, any>;

const COLORS = ["#1d4ed8", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"];

export default function ReportsPage() {
  // Page state.
  const [selectedReport, setSelectedReport] = useState("performance");

  // Typed aliases for imported mock data.
  const userList = users as unknown as AnyRecord[];
  const studentList = students as unknown as AnyRecord[];
  const resultList = examResults as unknown as AnyRecord[];
  const paymentList = payments as unknown as AnyRecord[];
  const attendanceList = attendance as unknown as AnyRecord[];
  const classList = classes as unknown as AnyRecord[];

  // Average performance per class.
  const classPerformance = useMemo(() => {
    return classList.map((classItem) => {
      const classResults = resultList.filter((result) => result.classId === classItem.id);
      const average = classResults.length
        ? Math.round(classResults.reduce((sum, result) => sum + Number(result.total ?? result.score ?? 0), 0) / classResults.length)
        : 0;

      return {
        name: classItem.name ?? "Class",
        average,
        students: studentList.filter((student) => student.classId === classItem.id).length,
      };
    });
  }, [classList, resultList, studentList]);

  // Attendance trend grouped by date.
  const attendanceTrend = useMemo(() => {
    const grouped = attendanceList.reduce<Record<string, { date: string; present: number; absent: number }>>((acc, item) => {
      const date = item.date ?? "Unknown";
      acc[date] = acc[date] ?? { date, present: 0, absent: 0 };
      const status = String(item.status ?? "present").toLowerCase();
      if (status === "present") acc[date].present += 1;
      else acc[date].absent += 1;
      return acc;
    }, {});

    return Object.values(grouped).slice(-10);
  }, [attendanceList]);

  // Fee collection summary.
  const feeSummary = useMemo(() => {
    const totalPaid = paymentList.reduce((sum, payment) => sum + Number(payment.amount ?? 0), 0);
    const pending = Math.max(studentList.length * 100000 - totalPaid, 0);

    return [
      { name: "Paid", value: totalPaid },
      { name: "Outstanding", value: pending },
    ];
  }, [paymentList, studentList]);

  // Grade distribution summary.
  const gradeDistribution = useMemo(() => {
    const counts = resultList.reduce<Record<string, number>>((acc, result) => {
      const grade = result.grade ?? "N/A";
      acc[grade] = (acc[grade] ?? 0) + 1;
      return acc;
    }, {});

    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [resultList]);

  return (
    <div className="space-y-6">
      {/* Header actions. */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Reports</h2>
          <p className="text-sm text-gray-500">Analyse performance, attendance, finance, and school activity</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button className="btn-secondary inline-flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filter
          </button>
          <button className="btn-primary inline-flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </button>
        </div>
      </div>

      {/* Report tabs. */}
      <div className="card p-4">
        <div className="flex flex-wrap gap-2">
          {[
            { id: "performance", label: "Performance", icon: BarChart3 },
            { id: "attendance", label: "Attendance", icon: TrendingUp },
            { id: "fees", label: "Fees", icon: PieIcon },
          ].map((item) => {
            const Icon = item.icon;
            const isActive = selectedReport === item.id;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedReport(item.id)}
                className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition ${
                  isActive ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Summary cards. */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="card p-5">
          <p className="text-sm text-gray-500">Total users</p>
          <p className="mt-2 text-2xl font-bold text-gray-900">{userList.length}</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-gray-500">Total students</p>
          <p className="mt-2 text-2xl font-bold text-gray-900">{studentList.length}</p>
        </div>
        <div className="card p-5">
          <p className="text-sm text-gray-500">Fees received</p>
          <p className="mt-2 text-2xl font-bold text-gray-900">{formatCurrency(paymentList.reduce((sum, payment) => sum + Number(payment.amount ?? 0), 0))}</p>
        </div>
      </div>

      {/* Performance report. */}
      {selectedReport === "performance" && (
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
          <div className="card p-5">
            <h3 className="mb-4 font-semibold text-gray-900">Class performance average</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={classPerformance}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="average" fill="#1d4ed8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="card p-5">
            <h3 className="mb-4 font-semibold text-gray-900">Grade distribution</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={gradeDistribution} dataKey="value" nameKey="name" outerRadius={100} label>
                    {gradeDistribution.map((entry, index) => (
                      <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Attendance report. */}
      {selectedReport === "attendance" && (
        <div className="card p-5">
          <h3 className="mb-4 font-semibold text-gray-900">Attendance trend</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={attendanceTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="present" stroke="#10b981" />
                <Line type="monotone" dataKey="absent" stroke="#ef4444" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Fees report. */}
      {selectedReport === "fees" && (
        <div className="card p-5">
          <h3 className="mb-4 font-semibold text-gray-900">Fee collection</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={feeSummary} dataKey="value" nameKey="name" outerRadius={110} label>
                  {feeSummary.map((entry, index) => (
                    <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatCurrency(Number(value))} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
