"use client";

import { useMemo, useState } from "react";
import { Plus, Search, Receipt, Download, CheckCircle, AlertCircle } from "lucide-react";
import { fees, payments, students, users, classes } from "@/lib/mockData";
import { formatCurrency, formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/Badge";

// Loose record type keeps this page safe even when mockData fields are not fully typed.
type AnyRecord = Record<string, any>;
type FeeTab = "fees" | "payments" | "debtors";

export default function FeesPage() {
  // Page filters and tab state.
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<FeeTab>("fees");

  // Cast imported mock data once, then use the typed aliases throughout the page.
  const feeList = fees as unknown as AnyRecord[];
  const paymentList = payments as unknown as AnyRecord[];
  const studentList = students as unknown as AnyRecord[];
  const userList = users as unknown as AnyRecord[];
  const classList = classes as unknown as AnyRecord[];

  // Resolve a student/user display name from different possible mock-data shapes.
  const getStudentUser = (studentId: string) => {
    const student = studentList.find((item) => item.id === studentId || item.userId === studentId);
    return userList.find((item) => item.id === studentId || item.id === student?.userId) ?? student;
  };

  // Resolve class information using either a student record or a fee record.
  const getClassName = (classId?: string) => {
    const classItem = classList.find((item) => item.id === classId);
    return classItem?.name ?? classItem?.title ?? "All classes";
  };

  // Search payments by student name, payment reference, method, or status.
  const filteredPayments = useMemo(() => {
    const query = search.trim().toLowerCase();

    return paymentList.filter((payment) => {
      const student = getStudentUser(payment.studentId);
      const haystack = [student?.name, payment.reference, payment.method, payment.status]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      return !query || haystack.includes(query);
    });
  }, [paymentList, search, studentList, userList]);

  // Build debtor rows by comparing class fees against student payments.
  const debtorRows = useMemo(() => {
    return studentList
      .map((student) => {
        const studentUser = getStudentUser(student.id ?? student.userId);
        const classFees = feeList.filter((fee) => !fee.classId || fee.classId === student.classId);
        const expected = classFees.reduce((sum, fee) => sum + Number(fee.amount ?? 0), 0);
        const paid = paymentList
          .filter((payment) => payment.studentId === student.id || payment.studentId === student.userId)
          .reduce((sum, payment) => sum + Number(payment.amount ?? 0), 0);
        const balance = Math.max(expected - paid, 0);

        return {
          id: student.id ?? student.userId,
          name: studentUser?.name ?? "Unknown student",
          className: getClassName(student.classId),
          expected,
          paid,
          balance,
        };
      })
      .filter((row) => row.balance > 0)
      .filter((row) => row.name.toLowerCase().includes(search.trim().toLowerCase()));
  }, [feeList, paymentList, search, studentList, userList]);

  // Page summary totals.
  const totalExpected = feeList.reduce((sum, fee) => sum + Number(fee.amount ?? 0), 0);
  const totalPaid = paymentList.reduce((sum, payment) => sum + Number(payment.amount ?? 0), 0);
  const totalOutstanding = debtorRows.reduce((sum, debtor) => sum + debtor.balance, 0);

  return (
    <div className="space-y-6">
      {/* Header actions. */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Fees</h2>
          <p className="text-sm text-gray-500">Manage school fees, payments, receipts, and outstanding balances</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button className="btn-secondary inline-flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export
          </button>
          <button className="btn-primary inline-flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add fee
          </button>
        </div>
      </div>

      {/* Summary cards. */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <div className="card p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Expected fees</p>
              <p className="mt-2 text-2xl font-bold text-gray-900">{formatCurrency(totalExpected)}</p>
            </div>
            <Receipt className="h-8 w-8 text-blue-600" />
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Payments received</p>
              <p className="mt-2 text-2xl font-bold text-gray-900">{formatCurrency(totalPaid)}</p>
            </div>
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <div className="card p-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Outstanding balance</p>
              <p className="mt-2 text-2xl font-bold text-gray-900">{formatCurrency(totalOutstanding)}</p>
            </div>
            <AlertCircle className="h-8 w-8 text-red-600" />
          </div>
        </div>
      </div>

      {/* Tabs and search. */}
      <div className="card p-4">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {(["fees", "payments", "debtors"] as FeeTab[]).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`rounded-lg px-4 py-2 text-sm font-medium capitalize transition ${
                  activeTab === tab ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="relative w-full lg:w-80">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search student, method, or reference"
              className="w-full rounded-lg border border-gray-200 py-2 pl-9 pr-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
            />
          </div>
        </div>
      </div>

      {/* Fees tab. */}
      {activeTab === "fees" && (
        <div className="card overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Fee</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Class</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Amount</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Due date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Type</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {feeList.map((fee) => (
                <tr key={fee.id ?? `${fee.name}-${fee.amount}`} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">{fee.name ?? fee.title ?? "Unnamed fee"}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{getClassName(fee.classId)}</td>
                  <td className="px-4 py-3 text-sm text-gray-900">{formatCurrency(Number(fee.amount ?? 0))}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{fee.dueDate ? formatDate(fee.dueDate) : "Not set"}</td>
                  <td className="px-4 py-3 text-sm text-gray-600"><Badge>{fee.type ?? "General"}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Payments tab. */}
      {activeTab === "payments" && (
        <div className="card overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Student</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Amount</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Method</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Date</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {filteredPayments.map((payment) => {
                const student = getStudentUser(payment.studentId);

                return (
                  <tr key={payment.id ?? payment.reference} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm font-medium text-gray-900">{student?.name ?? "Unknown student"}</td>
                    <td className="px-4 py-3 text-sm text-gray-900">{formatCurrency(Number(payment.amount ?? 0))}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{payment.method ?? "Not recorded"}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{payment.date ? formatDate(payment.date) : "Not set"}</td>
                    <td className="px-4 py-3 text-sm text-gray-600"><Badge>{payment.status ?? "Paid"}</Badge></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Debtors tab. */}
      {activeTab === "debtors" && (
        <div className="card overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Student</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Class</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Expected</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Paid</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Balance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {debtorRows.map((debtor) => (
                <tr key={debtor.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">{debtor.name}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{debtor.className}</td>
                  <td className="px-4 py-3 text-sm text-gray-900">{formatCurrency(debtor.expected)}</td>
                  <td className="px-4 py-3 text-sm text-gray-900">{formatCurrency(debtor.paid)}</td>
                  <td className="px-4 py-3 text-sm font-semibold text-red-600">{formatCurrency(debtor.balance)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
