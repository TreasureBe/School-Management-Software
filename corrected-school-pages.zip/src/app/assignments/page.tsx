"use client";

import { useState } from "react";
import { Plus, BookOpen, Calendar, CheckCircle, Clock, FileText } from "lucide-react";
import { assignments, subjects, classes, users } from "@/lib/mockData";
import { formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/Badge";

// Loose record type keeps this page compatible with flexible mock data.
type AnyRecord = Record<string, any>;

export default function AssignmentsPage() {
  // Page state and typed aliases.
  const [filterClass, setFilterClass] = useState("all");
  const assignmentList = assignments as unknown as AnyRecord[];
  const subjectList = subjects as unknown as AnyRecord[];
  const classList = classes as unknown as AnyRecord[];
  const userList = users as unknown as AnyRecord[];

  // Resolve display helpers.
  const filtered = filterClass === "all" ? assignmentList : assignmentList.filter((assignment) => assignment.classId === filterClass);
  const getSubjectName = (subjectId?: string) => subjectList.find((subject) => subject.id === subjectId)?.name ?? "Subject";
  const getClassName = (classId?: string) => classList.find((item) => item.id === classId)?.name ?? "Class";
  const getTeacherName = (teacherId?: string) => userList.find((user) => user.id === teacherId)?.name ?? "Teacher";

  return (
    <div className="space-y-6">
      {/* Header actions. */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Assignments</h2>
          <p className="text-sm text-gray-500">Create, review, and track class assignments</p>
        </div>

        <button className="btn-primary inline-flex items-center gap-2">
          <Plus className="h-4 w-4" />
          New assignment
        </button>
      </div>

      {/* Filter bar. */}
      <div className="card p-4">
        <select
          value={filterClass}
          onChange={(event) => setFilterClass(event.target.value)}
          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 md:w-72"
        >
          <option value="all">All classes</option>
          {classList.map((item) => (
            <option key={item.id} value={item.id}>{item.name}</option>
          ))}
        </select>
      </div>

      {/* Assignment cards. */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        {filtered.map((assignment) => {
          const dueDate = assignment.dueDate ?? assignment.deadline;
          const status = assignment.status ?? "active";

          return (
            <article key={assignment.id ?? assignment.title} className="card p-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-3">
                  <div className="rounded-xl bg-blue-100 p-2 text-blue-700">
                    <BookOpen className="h-5 w-5" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-semibold text-gray-900">{assignment.title ?? "Untitled assignment"}</h3>
                      <Badge>{status}</Badge>
                    </div>
                    <p className="text-sm leading-6 text-gray-600">{assignment.description ?? "No assignment description provided."}</p>
                  </div>
                </div>
              </div>

              <div className="mt-5 grid grid-cols-1 gap-3 text-sm text-gray-600 sm:grid-cols-2">
                <div className="flex items-center gap-2 rounded-lg bg-gray-50 p-3">
                  <FileText className="h-4 w-4 text-gray-400" />
                  {getSubjectName(assignment.subjectId)}
                </div>
                <div className="flex items-center gap-2 rounded-lg bg-gray-50 p-3">
                  <CheckCircle className="h-4 w-4 text-gray-400" />
                  {getClassName(assignment.classId)}
                </div>
                <div className="flex items-center gap-2 rounded-lg bg-gray-50 p-3">
                  <Clock className="h-4 w-4 text-gray-400" />
                  {getTeacherName(assignment.teacherId)}
                </div>
                <div className="flex items-center gap-2 rounded-lg bg-gray-50 p-3">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  {dueDate ? formatDate(dueDate) : "No due date"}
                </div>
              </div>
            </article>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="card p-8 text-center text-sm text-gray-500">No assignments match the selected class.</div>
      )}
    </div>
  );
}
