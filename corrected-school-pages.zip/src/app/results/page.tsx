"use client";

import { useMemo, useState } from "react";
import { FileText, Printer, Download, Search } from "lucide-react";
import { examResults, users, subjects, classes } from "@/lib/mockData";
import { Badge } from "@/components/ui/Badge";

// Loose record type keeps this page compatible with flexible mock data.
type AnyRecord = Record<string, any>;

export default function ResultsPage() {
  // Result filters.
  const [selectedClass, setSelectedClass] = useState("all");
  const [selectedStudent, setSelectedStudent] = useState("");

  // Typed aliases for imported mock data.
  const resultList = examResults as unknown as AnyRecord[];
  const userList = users as unknown as AnyRecord[];
  const subjectList = subjects as unknown as AnyRecord[];
  const classList = classes as unknown as AnyRecord[];

  // Resolve display helpers.
  const getStudentName = (studentId: string) => userList.find((user) => user.id === studentId)?.name ?? "Unknown student";
  const getSubjectName = (subjectId: string) => subjectList.find((subject) => subject.id === subjectId)?.name ?? "Subject";
  const getClassName = (classId: string) => classList.find((item) => item.id === classId)?.name ?? "Class";

  // Apply class and student-name filters.
  const filteredResults = useMemo(() => {
    const query = selectedStudent.trim().toLowerCase();

    return resultList.filter((result) => {
      const studentName = getStudentName(result.studentId).toLowerCase();
      const matchesStudent = !query || studentName.includes(query);
      const matchesClass = selectedClass === "all" || result.classId === selectedClass;
      return matchesStudent && matchesClass;
    });
  }, [resultList, selectedClass, selectedStudent, userList]);

  // Group result rows per student to make printing easier.
  const groupedByStudent = useMemo(() => {
    return filteredResults.reduce<Record<string, AnyRecord[]>>((groups, result) => {
      const studentId = result.studentId ?? "unknown";
      groups[studentId] = groups[studentId] ?? [];
      groups[studentId].push(result);
      return groups;
    }, {});
  }, [filteredResults]);

  return (
    <div className="space-y-6">
      {/* Header actions. */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Results</h2>
          <p className="text-sm text-gray-500">View, filter, print, and download student examination results</p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button className="btn-secondary inline-flex items-center gap-2">
            <Printer className="h-4 w-4" />
            Print
          </button>
          <button className="btn-primary inline-flex items-center gap-2">
            <Download className="h-4 w-4" />
            Download
          </button>
        </div>
      </div>

      {/* Filters. */}
      <div className="card p-4">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-[220px_1fr]">
          <select
            value={selectedClass}
            onChange={(event) => setSelectedClass(event.target.value)}
            className="rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
          >
            <option value="all">All classes</option>
            {classList.map((item) => (
              <option key={item.id} value={item.id}>{item.name}</option>
            ))}
          </select>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
            <input
              value={selectedStudent}
              onChange={(event) => setSelectedStudent(event.target.value)}
              placeholder="Search student name"
              className="w-full rounded-lg border border-gray-200 py-2 pl-9 pr-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
            />
          </div>
        </div>
      </div>

      {/* Results grouped by student. */}
      <div className="space-y-4">
        {Object.entries(groupedByStudent).map(([studentId, rows]) => {
          const total = rows.reduce((sum, row) => sum + Number(row.total ?? row.score ?? 0), 0);
          const average = rows.length ? Math.round(total / rows.length) : 0;
          const className = getClassName(rows[0]?.classId);

          return (
            <div key={studentId} className="card overflow-hidden">
              <div className="flex flex-col gap-3 border-b border-gray-100 bg-gray-50 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-3">
                  <div className="rounded-xl bg-blue-100 p-2 text-blue-700">
                    <FileText className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{getStudentName(studentId)}</h3>
                    <p className="text-sm text-gray-500">{className} • {rows.length} subjects</p>
                  </div>
                </div>
                <Badge>Average: {average}%</Badge>
              </div>

              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-white">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Subject</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Score</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Grade</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Remark</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {rows.map((row) => (
                    <tr key={row.id ?? `${studentId}-${row.subjectId}`} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium text-gray-900">{getSubjectName(row.subjectId)}</td>
                      <td className="px-4 py-3 text-sm text-gray-900">{row.total ?? row.score ?? 0}</td>
                      <td className="px-4 py-3 text-sm text-gray-600"><Badge>{row.grade ?? "N/A"}</Badge></td>
                      <td className="px-4 py-3 text-sm text-gray-600">{row.remark ?? row.remarks ?? "No remark"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        })}

        {filteredResults.length === 0 && (
          <div className="card p-8 text-center text-sm text-gray-500">No results match the selected filters.</div>
        )}
      </div>
    </div>
  );
}
