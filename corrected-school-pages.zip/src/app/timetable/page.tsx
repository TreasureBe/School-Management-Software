"use client";

import { useState } from "react";
import { Clock, MapPin, User } from "lucide-react";
import { timetable, subjects, users, classes } from "@/lib/mockData";
import { DAYS, TIME_SLOTS } from "@/lib/utils";

// Loose record type keeps this page compatible with flexible mock data.
type AnyRecord = Record<string, any>;

export default function TimetablePage() {
  // Page state.
  const classList = classes as unknown as AnyRecord[];
  const [selectedClass, setSelectedClass] = useState(classList[0]?.id ?? "");

  // Typed aliases for imported data.
  const timetableList = timetable as unknown as AnyRecord[];
  const subjectList = subjects as unknown as AnyRecord[];
  const userList = users as unknown as AnyRecord[];
  const days = DAYS as unknown as string[];
  const timeSlots = TIME_SLOTS as unknown as string[];

  // Resolve display helpers.
  const filtered = timetableList.filter((item) => item.classId === selectedClass);
  const selectedClassRecord = classList.find((item) => item.id === selectedClass);
  const getSubjectName = (subjectId?: string) => subjectList.find((subject) => subject.id === subjectId)?.name ?? "Free period";
  const getTeacherName = (teacherId?: string) => userList.find((user) => user.id === teacherId)?.name ?? "Unassigned";

  // Find one timetable entry for the selected day and time slot.
  const getSlot = (day: string, slot: string) => {
    return filtered.find((item) => {
      const itemSlot = item.timeSlot ?? item.slot ?? item.period ?? `${item.startTime ?? ""}-${item.endTime ?? ""}`;
      return item.day === day && itemSlot === slot;
    });
  };

  return (
    <div className="space-y-6">
      {/* Header and class selector. */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Timetable</h2>
          <p className="text-sm text-gray-500">View and manage class schedules</p>
        </div>

        <select
          value={selectedClass}
          onChange={(event) => setSelectedClass(event.target.value)}
          className="rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
        >
          {classList.map((item) => (
            <option key={item.id} value={item.id}>{item.name}</option>
          ))}
        </select>
      </div>

      {/* Selected class notice. */}
      <div className="card p-4">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-blue-100 p-2 text-blue-700">
            <Clock className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{selectedClassRecord?.name ?? "Selected class"}</h3>
            <p className="text-sm text-gray-500">Weekly timetable overview</p>
          </div>
        </div>
      </div>

      {/* Timetable grid. */}
      <div className="card overflow-x-auto">
        <table className="min-w-[900px] w-full border-collapse">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50">
              <th className="w-40 px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">Time</th>
              {days.map((day) => (
                <th key={day} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">{day}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {timeSlots.map((slot) => (
              <tr key={slot} className="align-top">
                <td className="bg-gray-50 px-4 py-4 text-sm font-medium text-gray-700">{slot}</td>
                {days.map((day) => {
                  const entry = getSlot(day, slot);

                  return (
                    <td key={`${day}-${slot}`} className="min-w-40 px-4 py-4">
                      {entry ? (
                        <div className="rounded-xl border border-blue-100 bg-blue-50 p-3">
                          <p className="font-semibold text-gray-900">{getSubjectName(entry.subjectId)}</p>
                          <p className="mt-2 flex items-center gap-1 text-xs text-gray-600">
                            <User className="h-3.5 w-3.5" />
                            {getTeacherName(entry.teacherId)}
                          </p>
                          <p className="mt-1 flex items-center gap-1 text-xs text-gray-600">
                            <MapPin className="h-3.5 w-3.5" />
                            {entry.room ?? entry.location ?? "No room"}
                          </p>
                        </div>
                      ) : (
                        <div className="rounded-xl border border-dashed border-gray-200 p-3 text-xs text-gray-400">Free</div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
