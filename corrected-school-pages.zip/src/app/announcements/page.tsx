"use client";

import { useState } from "react";
import { Plus, Bell, Calendar, AlertTriangle, Info, CheckCircle } from "lucide-react";
import { announcements, users } from "@/lib/mockData";
import { formatDate } from "@/lib/utils";
import { Badge } from "@/components/ui/Badge";

// Loose record type keeps this page compatible with flexible mock data.
type AnyRecord = Record<string, any>;
type Priority = "high" | "normal" | "low";

const priorityConfig: Record<Priority, { icon: typeof AlertTriangle; color: string }> = {
  high: { icon: AlertTriangle, color: "text-red-600 bg-red-50 border-red-200" },
  normal: { icon: Info, color: "text-blue-600 bg-blue-50 border-blue-200" },
  low: { icon: CheckCircle, color: "text-green-600 bg-green-50 border-green-200" },
};

export default function AnnouncementsPage() {
  // Modal state for the new announcement form shell.
  const [showModal, setShowModal] = useState(false);

  // Typed aliases for imported mock data.
  const announcementList = announcements as unknown as AnyRecord[];
  const userList = users as unknown as AnyRecord[];

  // Resolve author name when authorId exists.
  const getAuthorName = (authorId?: string) => userList.find((user) => user.id === authorId)?.name ?? "School admin";

  return (
    <div className="space-y-6">
      {/* Header actions. */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Announcements</h2>
          <p className="text-sm text-gray-500">Create and manage school-wide updates, alerts, and notices</p>
        </div>

        <button onClick={() => setShowModal(true)} className="btn-primary inline-flex items-center gap-2">
          <Plus className="h-4 w-4" />
          New announcement
        </button>
      </div>

      {/* Announcement feed. */}
      <div className="space-y-4">
        {announcementList.map((announcement) => {
          const priority = (announcement.priority ?? "normal") as Priority;
          const config = priorityConfig[priority] ?? priorityConfig.normal;
          const PriorityIcon = config.icon;

          return (
            <article key={announcement.id ?? announcement.title} className="card p-5">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex gap-3">
                  <div className={`rounded-xl border p-2 ${config.color}`}>
                    <PriorityIcon className="h-5 w-5" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-lg font-semibold text-gray-900">{announcement.title ?? "Untitled announcement"}</h3>
                      <Badge>{priority}</Badge>
                    </div>
                    <p className="text-sm leading-6 text-gray-600">{announcement.content ?? announcement.message ?? "No announcement content provided."}</p>
                    <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500">
                      <span className="inline-flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        {announcement.date ? formatDate(announcement.date) : "No date"}
                      </span>
                      <span>By {getAuthorName(announcement.authorId)}</span>
                      <span>Audience: {announcement.audience ?? "Everyone"}</span>
                    </div>
                  </div>
                </div>
              </div>
            </article>
          );
        })}

        {announcementList.length === 0 && (
          <div className="card p-8 text-center text-sm text-gray-500">No announcements have been created yet.</div>
        )}
      </div>

      {/* Lightweight modal shell. */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-blue-100 p-2 text-blue-700">
                <Bell className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Create announcement</h3>
                <p className="text-sm text-gray-500">Connect this form to your backend when write actions are ready.</p>
              </div>
            </div>

            <div className="mt-5 space-y-3">
              <input className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Announcement title" />
              <textarea className="min-h-28 w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Write announcement details" />
            </div>

            <div className="mt-6 flex justify-end gap-2">
              <button onClick={() => setShowModal(false)} className="btn-secondary">Cancel</button>
              <button onClick={() => setShowModal(false)} className="btn-primary">Save draft</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
