"use client";

import { useMemo, useState } from "react";
import { Send, Search, Mail, MailOpen, User } from "lucide-react";
import { messages, users } from "@/lib/mockData";
import { formatDate } from "@/lib/utils";

// Loose record type keeps this page compatible with flexible mock data.
type AnyRecord = Record<string, any>;

export default function MessagesPage() {
  // Typed aliases for imported mock data.
  const messageList = messages as unknown as AnyRecord[];
  const userList = users as unknown as AnyRecord[];

  // Page state.
  const [selectedMsg, setSelectedMsg] = useState<AnyRecord | null>(messageList[0] ?? null);
  const [reply, setReply] = useState("");
  const [search, setSearch] = useState("");

  // Resolve sender/receiver display names.
  const getUserName = (userId?: string) => userList.find((user) => user.id === userId)?.name ?? "Unknown user";

  // Filter messages by subject, body, or participant name.
  const filteredMessages = useMemo(() => {
    const query = search.trim().toLowerCase();

    return messageList.filter((message) => {
      const haystack = [
        message.subject,
        message.content,
        message.message,
        getUserName(message.senderId),
        getUserName(message.receiverId),
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      return !query || haystack.includes(query);
    });
  }, [messageList, search, userList]);

  return (
    <div className="space-y-6 h-[calc(100vh-8rem)]">
      {/* Header. */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Messages</h2>
          <p className="text-sm text-gray-500">Communicate with teachers, parents, students, and staff</p>
        </div>
      </div>

      {/* Main messaging layout. */}
      <div className="card flex min-h-0 flex-1 overflow-hidden">
        {/* Left inbox column. */}
        <aside className="w-full border-r border-gray-100 md:w-80">
          <div className="border-b border-gray-100 p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search messages"
                className="w-full rounded-lg border border-gray-200 py-2 pl-9 pr-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
            </div>
          </div>

          <div className="max-h-full overflow-y-auto">
            {filteredMessages.map((message) => {
              const isSelected = selectedMsg?.id === message.id;
              const isRead = Boolean(message.read ?? message.isRead);
              const Icon = isRead ? MailOpen : Mail;

              return (
                <button
                  key={message.id ?? `${message.senderId}-${message.subject}`}
                  type="button"
                  onClick={() => setSelectedMsg(message)}
                  className={`w-full border-b border-gray-100 p-4 text-left transition hover:bg-gray-50 ${isSelected ? "bg-blue-50" : "bg-white"}`}
                >
                  <div className="flex items-start gap-3">
                    <Icon className={`mt-1 h-4 w-4 ${isRead ? "text-gray-400" : "text-blue-600"}`} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-gray-900">{message.subject ?? "No subject"}</p>
                      <p className="truncate text-xs text-gray-500">From {getUserName(message.senderId)}</p>
                      <p className="mt-1 line-clamp-2 text-xs text-gray-500">{message.content ?? message.message ?? "No message body"}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        {/* Right reading pane. */}
        <section className="hidden min-w-0 flex-1 flex-col md:flex">
          {selectedMsg ? (
            <>
              <div className="border-b border-gray-100 p-5">
                <h3 className="text-lg font-semibold text-gray-900">{selectedMsg.subject ?? "No subject"}</h3>
                <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-gray-500">
                  <span className="inline-flex items-center gap-1">
                    <User className="h-4 w-4" />
                    {getUserName(selectedMsg.senderId)}
                  </span>
                  <span>{selectedMsg.date ? formatDate(selectedMsg.date) : "No date"}</span>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-5">
                <p className="whitespace-pre-wrap text-sm leading-6 text-gray-700">{selectedMsg.content ?? selectedMsg.message ?? "No message body"}</p>
              </div>

              <div className="border-t border-gray-100 p-4">
                <div className="flex gap-2">
                  <textarea
                    value={reply}
                    onChange={(event) => setReply(event.target.value)}
                    placeholder="Write a reply"
                    className="min-h-12 flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                  />
                  <button onClick={() => setReply("")} className="btn-primary self-end inline-flex items-center gap-2">
                    <Send className="h-4 w-4" />
                    Send
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-1 items-center justify-center text-sm text-gray-500">Select a message to read it.</div>
          )}
        </section>
      </div>
    </div>
  );
}
