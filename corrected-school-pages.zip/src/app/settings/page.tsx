"use client";

import { useState } from "react";
import { Save, Upload, School, GraduationCap, CreditCard, FileText, Shield } from "lucide-react";
import { schools } from "@/lib/mockData";

// Loose record type keeps this page compatible with flexible mock data.
type AnyRecord = Record<string, any>;
type SettingsTab = "general" | "academic" | "fees" | "results" | "users";

export default function SettingsPage() {
  // Page state.
  const [activeTab, setActiveTab] = useState<SettingsTab>("general");
  const [school, setSchool] = useState<AnyRecord>((schools as unknown as AnyRecord[])[0] ?? {});

  // Setting sections.
  const tabs: Array<{ id: SettingsTab; label: string; icon: typeof School }> = [
    { id: "general", label: "General", icon: School },
    { id: "academic", label: "Academic", icon: GraduationCap },
    { id: "fees", label: "Fees", icon: CreditCard },
    { id: "results", label: "Results", icon: FileText },
    { id: "users", label: "Users & Permissions", icon: Shield },
  ];

  // Generic form updater for the school settings object.
  const updateSchoolField = (field: string, value: string) => {
    setSchool((current) => ({ ...current, [field]: value }));
  };

  return (
    <div className="space-y-6">
      {/* Header. */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Settings</h2>
          <p className="text-sm text-gray-500">Manage school profile, academic rules, fees, results, and access controls</p>
        </div>

        <button className="btn-primary inline-flex items-center gap-2">
          <Save className="h-4 w-4" />
          Save changes
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[260px_1fr]">
        {/* Sidebar tabs. */}
        <aside className="card p-3">
          <nav className="space-y-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;

              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition ${
                    isActive ? "bg-blue-600 text-white" : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </aside>

        {/* General settings. */}
        {activeTab === "general" && (
          <section className="card p-6">
            <div className="flex items-center gap-3 border-b border-gray-100 pb-4">
              <div className="rounded-xl bg-blue-100 p-2 text-blue-700">
                <School className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">School profile</h3>
                <p className="text-sm text-gray-500">Basic public information about the school.</p>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
              <label className="space-y-1 text-sm">
                <span className="font-medium text-gray-700">School name</span>
                <input value={school.name ?? ""} onChange={(event) => updateSchoolField("name", event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2" />
              </label>

              <label className="space-y-1 text-sm">
                <span className="font-medium text-gray-700">Email</span>
                <input value={school.email ?? ""} onChange={(event) => updateSchoolField("email", event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2" />
              </label>

              <label className="space-y-1 text-sm">
                <span className="font-medium text-gray-700">Phone</span>
                <input value={school.phone ?? ""} onChange={(event) => updateSchoolField("phone", event.target.value)} className="w-full rounded-lg border border-gray-200 px-3 py-2" />
              </label>

              <label className="space-y-1 text-sm md:col-span-2">
                <span className="font-medium text-gray-700">Address</span>
                <textarea value={school.address ?? ""} onChange={(event) => updateSchoolField("address", event.target.value)} className="min-h-24 w-full rounded-lg border border-gray-200 px-3 py-2" />
              </label>
            </div>

            <button className="mt-5 btn-secondary inline-flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Upload logo
            </button>
          </section>
        )}

        {/* Academic settings. */}
        {activeTab === "academic" && (
          <section className="card p-6">
            <h3 className="text-lg font-semibold text-gray-900">Academic settings</h3>
            <p className="mt-1 text-sm text-gray-500">Configure session, term, grading, and promotion rules.</p>
            <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
              <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Current academic session" />
              <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Current term" />
              <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Pass mark" />
              <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Promotion average" />
            </div>
          </section>
        )}

        {/* Fee settings. */}
        {activeTab === "fees" && (
          <section className="card p-6">
            <h3 className="text-lg font-semibold text-gray-900">Fee settings</h3>
            <p className="mt-1 text-sm text-gray-500">Configure fee defaults, receipt numbering, and payment methods.</p>
            <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
              <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Receipt prefix" />
              <input className="rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Default currency" />
            </div>
          </section>
        )}

        {/* Result settings. */}
        {activeTab === "results" && (
          <section className="card p-6">
            <h3 className="text-lg font-semibold text-gray-900">Result settings</h3>
            <p className="mt-1 text-sm text-gray-500">Manage result templates, remarks, and publishing rules.</p>
            <div className="mt-6 space-y-3 text-sm text-gray-600">
              <label className="flex items-center gap-2"><input type="checkbox" /> Require principal approval before publishing results</label>
              <label className="flex items-center gap-2"><input type="checkbox" /> Show class position on report sheets</label>
              <label className="flex items-center gap-2"><input type="checkbox" /> Allow parents to download PDF copies</label>
            </div>
          </section>
        )}

        {/* User settings. */}
        {activeTab === "users" && (
          <section className="card p-6">
            <h3 className="text-lg font-semibold text-gray-900">Users & permissions</h3>
            <p className="mt-1 text-sm text-gray-500">Set role permissions for administrators, teachers, parents, and students.</p>
            <div className="mt-6 grid grid-cols-1 gap-3 md:grid-cols-2">
              {["Admin", "Teacher", "Parent", "Student"].map((role) => (
                <div key={role} className="rounded-xl border border-gray-200 p-4">
                  <p className="font-semibold text-gray-900">{role}</p>
                  <p className="mt-1 text-sm text-gray-500">Review and assign module permissions.</p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
